package com.example.final1;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class DeleteActivity extends Activity {
SQLiteHelper dbhelper;
SQLiteDatabase db;
Cursor c1,c2;
String record;
int eventnames,selectedevent;
Button delete,btn2;
Spinner eventspin;
List<String> eventlist;
AlertDialog.Builder builder;
ArrayAdapter<String> eventspinner;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_delete);
		dbhelper=new SQLiteHelper(this);
		db=dbhelper.getWritableDatabase();
		builder=new AlertDialog.Builder(this);
		delete=(Button)findViewById(R.id.button1);
		eventspin=(Spinner)findViewById(R.id.spinner1);
		eventlist=new ArrayList<String>();
		c1=db.rawQuery("select "+SQLiteHelper.LEAVEID+" from "+SQLiteHelper.TABLE_NAME3+" where " +SQLiteHelper.LEAVESTATUS + "=?",new String[]{"pending"});
		c1.moveToFirst();
		if(c1!=null){
			do{
				eventnames=c1.getInt(0);
				eventlist.add(Integer.toString((eventnames)));
			}while(c1.moveToNext());
		}
		eventspinner=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,eventlist);
		eventspinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		eventspin.setAdapter(eventspinner);
		eventspin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> parent, View v,
					int pos, long arg3) {
				// TODO Auto-generated method stub
				selectedevent=Integer.parseInt(parent.getItemAtPosition(pos).toString());
				
				c2=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME3+" where "+SQLiteHelper.LEAVEID+"="+selectedevent,null);
				c2.moveToFirst();
				record="";
				if(c2!=null){
					//status.setText(c2.getString(2));
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		
		});
		
		delete.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				builder.setTitle("Alert")
				.setMessage("Do you want to delete for sure")
				.setCancelable(false)
				.setPositiveButton("yes", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						String i=Integer.toString(selectedevent);
						// TODO Auto-generated method stub
						db.execSQL("DELETE FROM " + SQLiteHelper.TABLE_NAME3 +" WHERE "+SQLiteHelper.LEAVEID+"=?",new String[]{i});;
						//db.update(SQLiteHelper.TABLE_NAME3,cv,SQLiteHelper.LEAVEID+"="+selectedevent,null);
						 Toast.makeText(getApplicationContext(), "succesfully deleted", Toast.LENGTH_LONG).show();
					}
					
				})
				.setNegativeButton("no", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						 Toast.makeText(getApplicationContext(), "deleted cancelled", Toast.LENGTH_LONG).show();

					}
					
				});
				AlertDialog alert=builder.create();
				alert.setTitle("Alert");
				alert.show();
			
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.delete, menu);
		return true;
	}

}
