package com.example.final1;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;

 public class DashBoardActivity extends Activity {
TextView txt1;
String pass1,user;	
ImageButton btn1;
ImageButton btn2,btn3,btn4,btn5;
	@SuppressLint("NewApi") protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dash_board);
		txt1=(TextView)findViewById(R.id.welcome);
		Bundle bundle = getIntent().getExtras();
		 pass1 = bundle.getString("pass");
		 user = bundle.getString("user");
		 txt1.setText("Hi"+" "+pass1);
		 btn1=(ImageButton)findViewById(R.id.imageButton1);
		 btn2=(ImageButton)findViewById(R.id.imageButton2);
		 btn3=(ImageButton)findViewById(R.id.imageButton3);
		 btn4=(ImageButton)findViewById(R.id.imageButton4);
		 btn5=(ImageButton)findViewById(R.id.imageButton5);
		 
		 btn1.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DashBoardActivity.this, EmpDetailsActivity.class);
				 Bundle bundle = new Bundle();
				 bundle.putString("pass", pass1); 
				 intent.putExtras(bundle);
				 startActivity(intent);
			}
			 
		 });
		 btn2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(DashBoardActivity.this, LeaveFormActivity.class);
					 Bundle bundle = new Bundle();
					 bundle.putString("pass", pass1); 
					 intent.putExtras(bundle);
					 startActivity(intent);
				}
				 
			 });
		 btn3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(DashBoardActivity.this, LeaveStatusActivity.class);
					 Bundle bundle = new Bundle();
					 bundle.putString("pass", pass1); 
					 intent.putExtras(bundle);
					 startActivity(intent);
				}
				 
			 });
		 btn4.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(DashBoardActivity.this, PayslipuserActivity.class);
					 Bundle bundle = new Bundle();
					 bundle.putString("pass", pass1); 
					 bundle.putString("user", user);
					 intent.putExtras(bundle);
					 startActivity(intent);
				}
				 
			 });
		 btn5.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DashBoardActivity.this, HelpActivity.class);
				 startActivity(intent);
			}
			 
		 });
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		
		getMenuInflater().inflate(R.menu.dash_board, menu);
		return true;
	}

}
