package com.example.final1;

import android.app.ListFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FragMenu extends ListFragment {
	String[] AndroidOS= new String[]{"Button1","Button2","Button3","Button4"};
	String[] Version= new String[]{"Display's Employee Details","Leave Form Application","Leave Status View","Pay Slip View"};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view=inflater.inflate(R.layout.frag_menu, container);
		ArrayAdapter<String> adapter= new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,AndroidOS);
		setListAdapter(adapter);
		return view;
		
		//return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		FragDisplay txtfrag=(FragDisplay)getFragmentManager().findFragmentById(R.id.fragment2);
		txtfrag.change(AndroidOS[position],Version[position]);
		getListView().setSelector(android.R.color.holo_blue_bright);
		//super.onListItemClick(l, v, position, id);
	}

}
