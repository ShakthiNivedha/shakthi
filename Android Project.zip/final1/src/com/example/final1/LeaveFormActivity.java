package com.example.final1;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi") public class LeaveFormActivity extends Activity {
	SQLiteHelper dbhelper;
	SQLiteDatabase db;
EditText ed1,ed2,ed3,ed4,ed5;
String pass1;
String status;
String reason;
String from;
String to;
String splitTime1[];
String splitTime[];
int year_start1;
int year_start;
int month_start1;
int month_start;
int date_start1;
int date_start;
Button btn3;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_leave_form);
		Bundle bundle = getIntent().getExtras();
		 pass1 = bundle.getString("pass");
		 dbhelper=new SQLiteHelper(this);
        db=dbhelper.getWritableDatabase();
		ed1=(EditText)findViewById(R.id.editText1);
		ed1.setText(pass1);
		ed1.setEnabled(false);
		ed2=(EditText)findViewById(R.id.editText3);
		ed3=(EditText)findViewById(R.id.editText2);
		ed3.setText("pending");
		ed3.setEnabled(false);
		ed4=(EditText)findViewById(R.id.editText4);
		ed5=(EditText)findViewById(R.id.editText5); 
		Button btn1=(Button)findViewById(R.id.button1);
		Button btn2=(Button)findViewById(R.id.button2);
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LeaveFormActivity.this, DeleteActivity.class);
				startActivity(intent);
			}
			
		});
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				reason=ed2.getText().toString();
				status=ed3.getText().toString();
				from=ed4.getText().toString();
				to=ed5.getText().toString();
				String splitTime[]=from.split("-");
				year_start=Integer.parseInt(splitTime[0]);
				 month_start=Integer.parseInt(splitTime[1]);
				 date_start=Integer.parseInt(splitTime[2]);
				 String splitTime1[]=to.split("-");
				 year_start1=Integer.parseInt(splitTime1[0]);
				 month_start1=Integer.parseInt(splitTime1[1]);
				 date_start1=Integer.parseInt(splitTime1[2]);
				if(month_start <= month_start1 && date_start <= date_start1 &&  !reason.isEmpty() && !from.isEmpty() && !to.isEmpty() )
				{
					
					
					
					ContentValues values=new ContentValues();
			        values.put(SQLiteHelper.REASON, reason);
			        values.put(SQLiteHelper.LEAVESTATUS, status);
			        values.put(SQLiteHelper.USERNAME, pass1);
			        values.put(SQLiteHelper.FROMDATE, from); 
			        values.put(SQLiteHelper.TODATE, to);
			        
			        db.insert(SQLiteHelper.TABLE_NAME3,null, values); 
			        Toast.makeText(getApplicationContext(), "Succesfully saved", Toast.LENGTH_LONG).show();
			       
					
					 
				}
				else{
					 Toast.makeText(getApplicationContext(), "Please check the values entered", Toast.LENGTH_LONG).show();
				}
				

						
			
			}
			
		});
				

						
		
			
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.leave_form, menu);
		return true;
	}

}
