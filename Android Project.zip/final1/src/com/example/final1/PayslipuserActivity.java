package com.example.final1;

import android.os.Bundle;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PayslipuserActivity extends Activity {
EditText ed2;
TextView txt1,txt2,txt3,txt4,txt5,txt6;
Cursor c1,c2;
SQLiteDatabase db;
SQLiteHelper dbhelper;
String pass1,user,MON,YEAR,c,o;
int v,v1,f;
AutoCompleteTextView actv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_payslipuser);
		//ed1=(EditText)findViewById(R.id.editText1);
		ed2=(EditText)findViewById(R.id.editText2);
		txt1=(TextView)findViewById(R.id.textView7);
		txt2=(TextView)findViewById(R.id.textView8);
		txt3=(TextView)findViewById(R.id.textView9);
		txt4=(TextView)findViewById(R.id.textView4);
		txt5=(TextView)findViewById(R.id.textView5);
		txt6=(TextView)findViewById(R.id.textView6);
		Button btn=(Button)findViewById(R.id.button1);
		txt1.setVisibility(View.INVISIBLE);
		txt2.setVisibility(View.INVISIBLE);
		txt3.setVisibility(View.INVISIBLE);
		txt4.setVisibility(View.INVISIBLE);
		txt5.setVisibility(View.INVISIBLE);
		txt6.setVisibility(View.INVISIBLE);
		dbhelper=new SQLiteHelper(this);
        db=dbhelper.getWritableDatabase();
        Bundle bundle = getIntent().getExtras();
        pass1 = bundle.getString("pass");
		 user = bundle.getString("user");
		 final String[] month1={"january","february","march","april","may","june","july","august","september","october","november","december"};
		 ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,month1);
		 
		 
		 actv=(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView1);
		 actv.setAdapter(a);
		btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				
				// TODO Auto-generated method stub
				
				MON=actv.getText().toString();
				YEAR=ed2.getText().toString();
				if(!MON.isEmpty() && !YEAR.isEmpty())
				{
				c1=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME2 + " WHERE " + SQLiteHelper.EMP_NO + "=? AND "+SQLiteHelper.EMP_NAME + "=?" ,new String[]{user,pass1});
				c2=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME5 + " WHERE " + SQLiteHelper.USER + "=? AND " + SQLiteHelper.MONTH + "=? AND " + SQLiteHelper.YEAR + "=?",new String[]{user,MON,YEAR});
				c1.moveToFirst();
				if(c1!=null){
					if(c1.getColumnCount() >0){
						txt1.setVisibility(View.VISIBLE);
						txt1.setText(c1.getString(6));
						 v=Integer.parseInt(c1.getString(6));
					}
				}
				
			
						c2.moveToFirst();
						if(c2!=null){
							
							txt2.setVisibility(View.VISIBLE);
							txt3.setVisibility(View.VISIBLE);
							txt4.setVisibility(View.VISIBLE);
							txt5.setVisibility(View.VISIBLE);
							txt6.setVisibility(View.VISIBLE);
							
							
							 v1=c2.getInt(4);
							 f=v+v1;
								String d=Integer.toString(f);
								c=Integer.toString(c2.getInt(4));
								txt2.setText(c);
								 o=Integer.toString(f);
								txt3.setText(o);
						}
							
						}
				else{
					 Toast.makeText(getApplicationContext(), "Please check the values entered", Toast.LENGTH_LONG).show();
				}
						
				
				
			}
			
			
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.payslipuser, menu);
		return true;
	}

}
