package com.example.final1;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class DashBoard1Activity extends Activity {
ImageButton btn1,btn2;
Button btn4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dash_board1);
		btn1=(ImageButton)findViewById(R.id.imageButton1);
		btn2=(ImageButton)findViewById(R.id.imageButton2);
		btn4=(Button)findViewById(R.id.button1);
		btn4.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DashBoard1Activity.this, FrontpageActivity.class);
				startActivity(intent);
			}
			 
		 });
		btn1.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DashBoard1Activity.this, PayslipadminActivity.class);
				startActivity(intent);
			}
			 
		 });
		btn2.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DashBoard1Activity.this, UpdateActivity.class);
				startActivity(intent);
			}
			 
		 });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.dash_board1, menu);
		return true;
	}

}
