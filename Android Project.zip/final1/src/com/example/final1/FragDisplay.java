package com.example.final1;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FragDisplay extends Fragment {
	TextView name,version;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view=inflater.inflate(R.layout.frag_display,container,false);
		name=(TextView)view.findViewById(R.id.textView1);
		version=(TextView)view.findViewById(R.id.textView2);
		return view;
		
		//return super.onCreateView(inflater, container, savedInstanceState);
	}
	public void change(String input1,String input2){
		name.setText(input1);
		version.setText(input2);
		
	}

}
