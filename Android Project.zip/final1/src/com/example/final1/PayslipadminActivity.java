package com.example.final1;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PayslipadminActivity extends Activity {
	String pass1;
	EditText ed1,ed3,ed4;
	String name,month,othours;
	int rate,year,hours,min;
	Button btn1,btn2;
	Cursor c1,c2;
	SQLiteHelper dbhelper;
	SQLiteDatabase db;
	String year1;
	AutoCompleteTextView actv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_payslipadmin);
		dbhelper=new SQLiteHelper(this);
        db=dbhelper.getWritableDatabase();
		 ed1=(EditText)findViewById(R.id.editText1);
		// ed2=(EditText)findViewById(R.id.editText2);
		 final String[] month1={"january","february","march","april","may","june","july","august","september","october","november","december"};
		 ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,month1);
		 
		 
		 actv=(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView1);
		 actv.setAdapter(a);
		 ed3=(EditText)findViewById(R.id.editText3);
		 ed4=(EditText)findViewById(R.id.editText4);
		btn1=(Button)findViewById(R.id.button1);
		btn2=(Button)findViewById(R.id.button2);
		btn2.setOnClickListener(new OnClickListener()
		 {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(PayslipadminActivity.this,DashBoard1Activity.class);
				startActivity(intent);
			}
			 
		 });
		btn1.setOnClickListener(new OnClickListener(){

			@SuppressLint("NewApi") @Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				
				name=ed1.getText().toString();
				 month=actv.getText().toString();
				 othours=ed4.getText().toString();
				 year=Integer.parseInt(ed3.getText().toString());
				 year1=ed3.getText().toString();
				if(!name.isEmpty() && !month.isEmpty() && !othours.isEmpty() ){
					 String splitTime[]=othours.split(":");
						hours=Integer.parseInt(splitTime[0]);
						min=Integer.parseInt(splitTime[1]);
						rate=hours*75+min*5; 
						 c1=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME + " WHERE " + SQLiteHelper.ID + "=?",new String[]{name});
						 if(c1 !=null)
						 {
							 if(c1.getCount() >0 )
							{
								 c2=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME5 + " WHERE " + SQLiteHelper.USER + "=? AND " + SQLiteHelper.MONTH + "=? AND " + SQLiteHelper.YEAR + "=?",new String[]{name,month,year1});
								 if(c2 !=null)
								 {
									 if(c2.getCount() >0){
										 Toast.makeText(getApplicationContext(), "Payslip already updated", Toast.LENGTH_LONG).show();   
									 } 
									 else{
										 ContentValues values=new ContentValues();
									        values.put(SQLiteHelper.USER, name);
									        values.put(SQLiteHelper.HOURS, othours);
									        values.put(SQLiteHelper.YEAR, year);
									        values.put(SQLiteHelper.MONTH, month); 
									        values.put(SQLiteHelper.AMOUNT, rate);
									        
									        db.insert(SQLiteHelper.TABLE_NAME5,null, values); 
									        Toast.makeText(getApplicationContext(), "Succesfully saved", Toast.LENGTH_LONG).show();
									 }
								 }
									 
								 }    
								 
							}
							 else{
								 Toast.makeText(getApplicationContext(), "Please check userid refered", Toast.LENGTH_LONG).show();
							 }
						 }
				
				else{
					 Toast.makeText(getApplicationContext(), "Please check the values entered", Toast.LENGTH_LONG).show();
				}
				
				
				
			}
			
			
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.payslipadmin, menu);
		return true;
	}

}
