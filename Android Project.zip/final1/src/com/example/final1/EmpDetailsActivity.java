package com.example.final1;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class EmpDetailsActivity extends Activity {
TextView txt1;
TextView txt2;
TextView txt3;
TextView txt4;
TextView txt5;
Cursor cursor;
String pass1;
SQLiteHelper dbhelper;
SQLiteDatabase db;
String DOJ;
String dor;
String desig;
String basic_pay;
Button btn1; 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_emp_details);
		txt1=(TextView)findViewById(R.id.empname);
		txt2=(TextView)findViewById(R.id.doj);
		txt3=(TextView)findViewById(R.id.dor);
		txt4=(TextView)findViewById(R.id.desig);
		txt5=(TextView)findViewById(R.id.sal);
		
		Bundle bundle = getIntent().getExtras();
		 pass1 = bundle.getString("pass");
		 txt1.setText(pass1); 
		 dbhelper=new SQLiteHelper(this);
         db=dbhelper.getReadableDatabase();
          cursor=db.rawQuery("SELECT * FROM "+SQLiteHelper.TABLE_NAME,null);
         DOJ="";
         dor="";
         desig="";
         basic_pay="";
         cursor=db.rawQuery("select * from "+SQLiteHelper.TABLE_NAME2+" WHERE "+SQLiteHelper.EMP_NAME+"=?",new String[]{pass1});;
         
         cursor.moveToFirst();
		 if(cursor!=null){
			 txt2.setText(cursor.getString(3));
			 txt3.setText(cursor.getString(4));
			 txt4.setText(cursor.getString(5));
			 txt5.setText(cursor.getString(6));
		 }
         
         
        
         else{
    		 Toast.makeText(getApplicationContext(), "Sorry error in displaying please check again", Toast.LENGTH_LONG).show();
    	 }
		 
		 
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.emp_details, menu);
		return true;
	}

}
