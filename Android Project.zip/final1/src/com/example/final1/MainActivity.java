package com.example.final1;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	SQLiteHelper dbhelper;
	SQLiteDatabase db;
	String record;
	EditText username,password;
	Button btn;
	String user;
	String pass1;
	TextView txt1;
	private Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         username=(EditText)findViewById(R.id.editText1);
         password=(EditText)findViewById(R.id.editText2);
         txt1=(TextView)findViewById(R.id.textView1);
         Button btn=(Button)findViewById(R.id.button1);
         dbhelper=new SQLiteHelper(this);
         db=dbhelper.getWritableDatabase();
       
        
      
      btn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				
				// TODO Auto-generated method stub
				 user=(username.getText().toString());
				 pass1=password.getText().toString();
				 cursor=db.rawQuery("select *from "+SQLiteHelper.TABLE_NAME + " WHERE " + SQLiteHelper.ID + "=? AND " + SQLiteHelper.PASSWORD + "=?",new String[]{user,pass1});
				 if(cursor !=null)
				 {
					 if(cursor.getCount() >0){
						 Intent intent = new Intent(MainActivity.this, DashBoardActivity.class);
						 Bundle bundle = new Bundle();
						 bundle.putString("pass", pass1); 
						 bundle.putString("user", user);
						 intent.putExtras(bundle);
						 startActivity(intent);
						 Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_LONG).show();
					}
					 else{
						 Toast.makeText(getApplicationContext(), "please enter valid details", Toast.LENGTH_LONG).show();
					 }
				 }
			       
	
			       
				
			}

			
        	 
         }); 
         
         
    }
    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
