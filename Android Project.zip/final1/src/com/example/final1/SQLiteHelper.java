package com.example.final1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {
	public static final String DATABASE_NAME="mydb1";
	public static final int DATABASE_VERSION=1;
	public static final String TABLE_NAME = "logins";
	public static final String ID="id";
	public static final String PASSWORD="pass";
	public static final String TABLE_NAME2="empdetails";
	public static final String EMP_NO="empno";
	public static final String EMP_NAME="empname";
	public static final String DOB="dob";
	public static final String DOJ="doj";
	public static final String DOR="dor";
	public static final String DESIGNATION="desig_name";
	public static final String BASICPAY="basicpay";
	public static final String TABLE_NAME3="leavedetails1";
	public static final String LEAVEID="leaveid";
	public static final String REASON="reason";
	public static final String USERNAME="username";
	public static final String FROMDATE="fromdate";
	public static final String TODATE="todate";
	public static final String LEAVESTATUS="leavestatus";
	public static final String TABLE_NAME5 = "payslip1";
	public static final String USER="uname";
	public static final String HOURS="hours";
	public static final String YEAR="year";
	public static final String MONTH="month";
	public static final String AMOUNT="amt";
	
	public SQLiteHelper(Context context) 
	{
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
	//db.execSQL("CREATE TABLE "+TABLE_NAME+" ("+ID+" INTEGER PRIMARY KEY,"+PASSWORD+" VARCHAR(255)");
	String query="CREATE TABLE " +TABLE_NAME + " (" +ID+ " INTEGER PRIMARY KEY, " +PASSWORD+ " VARCHAR(255)) ";	
	db.execSQL(query);
	String query2="CREATE TABLE IF NOT EXISTS "+SQLiteHelper.TABLE_NAME2 + " (" +SQLiteHelper.EMP_NO+ " INTEGER, " +SQLiteHelper.EMP_NAME+ " VARCHAR(255),"+SQLiteHelper.DOB+" VARCHAR(255), "+SQLiteHelper.DOJ+" VARCHAR(255), "+SQLiteHelper.DOR+" VARCHAR(255), "+SQLiteHelper.DESIGNATION+" VARCHAR(255), "+SQLiteHelper.BASICPAY+" VARCHAR(200))"; 
   	db.execSQL(query2);
   	
    String query3="CREATE TABLE IF NOT EXISTS "+SQLiteHelper.TABLE_NAME3 + " (" +SQLiteHelper.LEAVEID+ " INTEGER PRIMARY KEY AUTOINCREMENT , " +SQLiteHelper.REASON+ " VARCHAR(255),"+SQLiteHelper.LEAVESTATUS+" VARCHAR(255), "+SQLiteHelper.USERNAME+" VARCHAR(255), "+SQLiteHelper.FROMDATE+" VARCHAR(255), "+SQLiteHelper.TODATE+" VARCHAR(255) )"; 
 	db.execSQL(query3);
 	
 	String query4="CREATE TABLE IF NOT EXISTS "+SQLiteHelper.TABLE_NAME5 + " (" +SQLiteHelper.USER+ " INTEGER , " +SQLiteHelper.HOURS+ " TIME ,"+SQLiteHelper.YEAR+" INTEGER, "+SQLiteHelper.MONTH+" VARCHAR(255), "+SQLiteHelper.AMOUNT+" INTEGER )"; 
   	db.execSQL(query4);
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

}
