package com.example.final1;

import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.Window;

public class SplashActivity extends Activity {
long delay=8000;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_splash);
		Timer runsplash=new Timer();
		TimerTask showsplash=new TimerTask(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				finish();
				Intent intent=new Intent(SplashActivity.this,FrontpageActivity.class);
				startActivity(intent);
			}
		
		};
		runsplash.schedule(showsplash, delay);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash, menu);
		return true;
	}

}
