package com.loginpages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uemail=request.getParameter("username");
		String upwd=request.getParameter("password");
		 int emp_id=786461;
		
		RequestDispatcher dispatcher=null;
		try
		{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			PreparedStatement pst=con.prepareStatement("select * from user1 where id=? and pass_user=?");
			pst.setString(1, uemail);
			pst.setString(2, upwd);
			
			
			ResultSet rs=pst.executeQuery();
			
			
			if(rs.next())
			{				
				String emp_name=rs.getString("emp_name");
				int id=rs.getInt("id");
				HttpSession session=request.getSession(true);
				session.setAttribute("emp_name",emp_name);
				session.setAttribute("id", id);	
				dispatcher=request.getRequestDispatcher("index_user.jsp");	
			} 
			else	
			{	
				dispatcher=request.getRequestDispatcher("login.jsp");
			   	request.setAttribute("myname","Please enter correct values");
			}
			dispatcher.forward(request, response);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
