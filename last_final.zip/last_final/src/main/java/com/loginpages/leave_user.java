package com.loginpages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class leave_user
 */
@WebServlet("/leave_user")
public class leave_user extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String grade;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int hrms_id=Integer.parseInt(request.getParameter("labelvalue1"));
		
		
		int days=Integer.parseInt(request.getParameter("no"));
		String nature_leave=request.getParameter("nature");
		String reason=request.getParameter("reason");
		String start_date=request.getParameter("sd");
		String end_date=request.getParameter("ed"); 
		LocalDate date = LocalDate.now();
		String out=date.toString();
		RequestDispatcher dispatcher=null;
		RequestDispatcher dispatcher1=null;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			PreparedStatement pst1=con.prepareStatement("select desig_name from designation_entry1 where userid=?");
			pst1.setInt(1, hrms_id);
			ResultSet rs=pst1.executeQuery();
			if(rs.next())
			{ 
				grade=rs.getString("desig_name");
			}
			System.out.println("check1");
			PreparedStatement pst=con.prepareStatement("insert into leave_details5(curr_date,curr_month,no_of_days,reason,nature_of_leave,leave_status,from_date,to_date,grade,userid) values(?,?,?,?,?,?,?,?,?,?)");
			String splitTime[]=start_date.split("-");
			
			int year_start=Integer.parseInt(splitTime[0]);
			int month_start=Integer.parseInt(splitTime[1]);
			int date_start=Integer.parseInt(splitTime[2]);
			String splitTime_end[]=end_date.split("-");
			int year_end=Integer.parseInt(splitTime_end[0]);
			int month_end=Integer.parseInt(splitTime_end[1]);
			int date_end=Integer.parseInt(splitTime_end[2]);
			LocalDate dat = LocalDate.now();
			Month month = date.getMonth();
			String currentmonth=month.toString();
			
			int check_days=(date_end - date_start)+1;
			if((date_start < date_end || date_start == date_end) && (month_start < month_end || month_start == month_end) && (year_start < year_end || year_start == year_end) && days==check_days && reason.matches("[A-Za-z]*"))
			{
				pst.setString(1, out);
				pst.setString(2, currentmonth);
				pst.setInt(3,days);
				pst.setString(4,reason);
				pst.setString(5,nature_leave);
				String leave_status="Pending";
				pst.setString(6, leave_status);
				pst.setString(7,start_date);
				pst.setString(8,end_date);
				pst.setString(9,grade);
				System.out.println(grade);
				pst.setInt(10,hrms_id);
				
			}
			else
			{
				dispatcher1=request.getRequestDispatcher("leave_user.jsp");
				
				request.setAttribute("myname","Please Check the values entered");
				dispatcher1.forward(request, response);
				con.close();
			}
			
			int row_count = pst.executeUpdate();
			if(row_count >0)
			   {
				dispatcher=request.getRequestDispatcher("index_user.jsp");
			    
			   }
			else
			{
				dispatcher=request.getRequestDispatcher("leave_user.jsp");
			}
			dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
