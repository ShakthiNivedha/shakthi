package com.loginpages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

/**
 * Servlet implementation class view_issued_pass
 */
@WebServlet("/view_issued_pass")
public class view_issued_pass extends HttpServlet {
	private static final long serialVersionUID = 1L;
        String currentdate;
        String expiry_date;
		int cur_time;
		int currenttime;
		int memberid;
		String currentyear;
		String desig_name;
		String division;
		int unit_no;
		String member_name;
		String member_rel;
		String station_from;
		String station_to;
		RequestDispatcher dispatcher;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int grade=(int)request.getSession(false).getAttribute("id");
		int pass_number=Integer.parseInt(request.getParameter("sha"));
		String m_name;
		String f_rel;
		
		System.out.println(pass_number);
		try { 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			PreparedStatement pst1=con.prepareStatement("select currentyear,station_from,station_to,currentdate,expiry_date,currenttime from pass_booking13 where userid=? and unique_pass_number=?");
			pst1.setInt(1,grade);
			pst1.setInt(2,pass_number);
		    ResultSet rs1=pst1.executeQuery();
		    
		    PreparedStatement pst2=con.prepareStatement("select desig_name,division,unit_no from designation_entry1 where userid=?");
		    pst2.setInt(1,grade);
			ResultSet rs2=pst2.executeQuery();
			if(rs2.next()) {
				desig_name=rs2.getString("desig_name");
				division=rs2.getString("division");
				unit_no=rs2.getInt("unit_no"); 
			}
			
			PreparedStatement pst3=con.prepareStatement("select memberid from members_inclued_in_pass13 where userid=? and current_date_booking=? and currenttime=?");  

			pst3.setInt(1,grade);			
			
			if(rs1.next()){
				station_from=rs1.getString("station_from");
				station_to=rs1.getString("station_to");
				currentyear=rs1.getString("currentyear");
				currentdate=rs1.getString("currentdate");
				expiry_date=rs1.getString("expiry_date");
				currenttime=rs1.getInt("currenttime");
			}
			pst3.setString(2,currentdate);  
			pst3.setInt(3, currenttime);   
			
			ResultSet rs4=pst3.executeQuery();
			
			
		    
			
			PreparedStatement pst4=con.prepareStatement("select member_name,family_rel from emp_family1 where member_id=?");
		
			if(rs4.next()){
				memberid=rs4.getInt("memberid");
				System.out.println(rs4.getInt("memberid"));
			}
			pst4.setInt(1, memberid);
			ResultSet rs5=pst4.executeQuery();
			if(rs5.next()) {
				
				member_name=rs5.getString("member_name");
				member_rel=rs5.getString("family_rel");
				
			} 
		/*	ResultSetMetaData rsMetaData = (ResultSetMetaData) rs5.getMetaData();
			int columnsNumber = rsMetaData.getColumnCount();
			 System.out.println(columnsNumber);
			while (rs5.next()) {
			       for (int i = 1; i <columnsNumber ; i++) {
			    	   System.out.println("this1");
			           if (i > 1) System.out.print(",  ");
			           System.out.println("this2");
			            m_name = rs5.getString("member_name");
			            System.out.println("this4");
			            f_rel=rs5.getString("family_rel");
			           
			           System.out.print(m_name+","+f_rel);
			       }
			       System.out.println("");
			   }
			*/
			
			
			
			if(currentdate!=expiry_date) {
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<meta charset=UTF-8>");
			out.println("<title>Issued Pass</title>");
			out.println("<style type=text/css>");
			out.println(".box_pass{");
			out.println("width:1000px;");
			out.println("height:550px;");
			out.println("padding-left:45px;");
			out.println("margin-top:75px;");
			out.println("margin-left:10px;");
			out.println("border:1px solid black;");
			out.println("box-sizing:border-box;");
			out.println("text-align:center;");
			out.println("padding-right:30px;");
			out.println("background-image:url(images_login/issuedpassimg.jpeg);");
			out.println("background-size:cover;");
			out.println("}");
			out.println(".align{");
			out.println("text-align:left;");
			out.println("}");
			out.println(".align1{");
			out.println("text-align:center;");
			out.println("text-decoration:underline;");
			out.println("}");
			out.println("body{");
			out.println("padding-top:0px;");
			out.println("line-height:1.0;");
			out.println("}");
			out.println(" button{ ");
		    out.println("font-size:24px;");
		   
		    out.println("background-color:white; ");
		    out.println("color:black; ");
			out.println("cursor:pointer;");
			out.println("margin:4px 5px; "); 
			out.println("padding:10px 22px; ");
			out.println("}");
			out.println(".align3{");
			out.println("text-align:center;");
			out.println("}");
			out.println(".align2{");
			out.println("text-align:right;");
			out.println("padding-right:30px;");
			out.println("}");
			out.println("a{color:black;");
			out.println("text-decoration:none;}");
			out.println("</style>");
			out.println("</head>");
			out.println("<body>");
			 out.println("<a  href=index_user.jsp >HOME</a>");
			out.println("<center>");
			out.println("<div class=box_pass >");
			out.println("<div class=align1><h1> e-Pass </h1>");
			out.println("<h2>MINISTRY OF RAILWAY</h2></div>");
			out.println("<h3>UPN : 102"+grade+"432 &emsp; &emsp; &emsp; &emsp; &emsp;  &emsp; &emsp;  &emsp; &emsp; Pass Year:"+currentyear+" &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;   Issued Date :"+currentdate+"</h3>");
			out.println("<div class=align1><h2> INDIAN RAILWAY</h2></div>");
			out.println("<div class=align3><p style=line-height:1.6;>This pass allows traveling with 140 kg of luggage free for each adult and half of that quantity for each child and one attendent in Second Class with 50 kgs luggage.</p>");
			out.println("</div><div class=align><h5>Designation Name : "+desig_name+"</h5>");
			out.println("<h5>Division : "+division+" </h5>");
			out.println("<h5> Unit No : "+unit_no+" </h5>"); 
			out.println("<div class=align3><h3>Issued Pass Members:"+member_name+"/"+member_rel+"</h3></div>"); 
			out.println("<h4>From:"+station_from+"</h4>");
			out.println("<h4>To:"+station_to+"</h4>");
			out.println("</div>");
			out.println("<div class=align2>");
			out.println("<h3>Expiry Date:"+expiry_date+"</h3> ");
			out.println("</div>");
			out.println("</div>");
			out.println("<center><button id=btn onclick=hideButton(),window.print() >Print the Slip </button><center>");
			out.println("<script type=text/javascript>");
			out.println("function hideButton(){");
		    
		    out.println("document.getElementById('btn').style.visibility= 'hidden';}"); 
		    
		    out.println("</script>"); 
		    out.println("</center>");
			out.println("</body>");
			out.println("</html>");
			}
			else {
			    dispatcher=request.getRequestDispatcher("MyIssuedPass.jsp");
			   	request.setAttribute("myname","You are exceeded the time limit ");
			   	dispatcher.forward(request, response);
			}
			
		}
		catch(Exception ee) {
			ee.printStackTrace();
		}
	}

}
