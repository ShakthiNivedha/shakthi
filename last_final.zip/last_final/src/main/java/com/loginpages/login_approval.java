package com.loginpages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login_approval
 */
@WebServlet("/login_approval")
public class login_approval extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname1=request.getParameter("uname");
		String upass=request.getParameter("pass");
		
		RequestDispatcher dispatcher=null;
		
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			PreparedStatement pst1=con.prepareStatement("select * from admin2 where username=? and pass_admin=?");
			
			pst1.setString(1, uname1);
			pst1.setString(2, upass);
			ResultSet rs1=pst1.executeQuery();
			if(rs1.next())
			{
				String admin_name=rs1.getString("username");
				String pass_admin=rs1.getString("pass_admin");
				HttpSession session=request.getSession(true);
				session.setAttribute("admin_name",admin_name);
				session.setAttribute("admin_pass",pass_admin);
				System.out.println(admin_name);
				dispatcher=request.getRequestDispatcher("update_leave_approval_step1.jsp");
			}
			else
			{
				dispatcher=request.getRequestDispatcher("login_admin.jsp");
				request.setAttribute("myname","Please enter correct values");
			}
			dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	}

}
