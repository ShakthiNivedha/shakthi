package com.loginpages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class logic_for_leave_approval
 */
@WebServlet("/logic_for_leave_approval")
public class logic_for_leave_approval extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String[] checkedIds = request.getParameterValues("checkedRows");
		
		PrintWriter out = response.getWriter();
		out.println(checkedIds);
	}

}
