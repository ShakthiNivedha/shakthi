package com.loginpages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Year;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class pass_booking
 */
@WebServlet("/pass_booking")
public class pass_booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
   int count;
   String expiry_date;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String s_from=request.getParameter("Sfrom");
		String s_to=request.getParameter("Sto");
		int id=(int)request.getSession(false).getAttribute("id");
		
		RequestDispatcher dispatcher=null;
		RequestDispatcher dispatcher1=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			LocalDate date = LocalDate.now();
			String currentdate=date.toString();
			int currentyear = Year.now().getValue();
			Month month = date.getMonth();
			String currentmonth=month.toString();
			LocalDateTime dateTime = LocalDateTime.now();
			int hour=dateTime.getHour();
			int minutes=dateTime.getMinute();
			String values=hour+":"+minutes;
			PreparedStatement pst2=con.prepareStatement("SELECT CURDATE()");
			 ResultSet rs3=pst2.executeQuery();
			 if(rs3.next()){
				 String value=rs3.getString(1);
				 String splitTime[]=value.split("-");
					
					int year_start=Integer.parseInt(splitTime[0]);
					int month_start=Integer.parseInt(splitTime[1]);
					int date_start=Integer.parseInt(splitTime[2]);
					int month_expiry=month_start+1;
					int val=1;
					expiry_date=year_start+"-"+month_expiry+"-"+date_start;
					
					
			 }
			
			PreparedStatement pst=con.prepareStatement("insert into pass_booking13(station_from,station_to,currentdate,currentmonth,currentyear,userid,currenttime,expiry_date) values(?,?,?,?,?,?,?,?)");
			
			pst.setString(1, s_from);
			pst.setString(2, s_to);
			pst.setString(3, currentdate);
			pst.setString(4, currentmonth);
			pst.setInt(5, currentyear);
			pst.setInt(6, id);
			pst.setInt(7,minutes);
			pst.setString(8, expiry_date);
			
			PreparedStatement pst7=con.prepareStatement("select unique_pass_number from pass_booking13 where userid=?");
			pst7.setInt(1,id);
			ResultSet rs7=pst7.executeQuery();
			if(rs7.next()) {
				
				String unique=rs7.getString("unique_pass_number"); 
				HttpSession session=request.getSession(true); 
				session.setAttribute("unique",unique); 
				
			}
			String sql="select COUNT(*) from pass_booking13 where userid=?";
			PreparedStatement pst1=con.prepareStatement(sql);
			pst1.setInt(1,id);
			ResultSet rs=pst1.executeQuery();
			if(rs.next())
			{
			 count=rs.getInt(1);
			}
	
			if(count >2) 
			{
				dispatcher=request.getRequestDispatcher("pass_booking.jsp");
				request.setAttribute("myname", "You have crossed your pass limit!");
			}
			else {
				int row_count = pst.executeUpdate();
				if(row_count >0)
				   {
						
						dispatcher=request.getRequestDispatcher("meaber_to_be_inclued.jsp");
					    
				   }
				 else 
				 {
					 dispatcher=request.getRequestDispatcher("pass_booking.jsp");
					 request.setAttribute("myname", "Seems you have entered wrongly");
				 }
			}
			
			
			
			 dispatcher.forward(request, response);
		}
		catch(Exception ee)
		{
			System.out.println("error");
			
		}
		
	}

}
