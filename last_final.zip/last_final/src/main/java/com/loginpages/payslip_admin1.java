package com.loginpages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class payslip_admin
 */
@WebServlet("/payslip_admin")
public class payslip_admin1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String ot_hours=request.getParameter("hours");
		String month=request.getParameter("mon");
		int id=Integer.parseInt(request.getParameter("username")); 
		int year_ps=Integer.parseInt(request.getParameter("year"));
		int row_count ;
		
		RequestDispatcher dispatcher=null;
		RequestDispatcher dispatcher1=null;
		RequestDispatcher dispatcher3=null;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
			  System.out.println(con);
			 PreparedStatement pst1=con.prepareStatement("select *from empdetails2 where user_id=?");
			  pst1.setInt(1, id);
			  ResultSet rs1=pst1.executeQuery();
			  if(rs1.next())
			  {
				  System.out.println("verified that user exists");
			  }
			  else
			  {
				  	dispatcher3=request.getRequestDispatcher("payslip_admin.jsp");
					request.setAttribute("myname","You have entered an User that doesn't exists");
					dispatcher3.forward(request, response);
					con.close();
			  }
			  
			 PreparedStatement pst2=con.prepareStatement("select *from pay_slip8 where month_i=? and year_p=? and userid=?");
			  pst2.setString(1,month);
			  pst2.setInt(2, year_ps);
			  pst2.setInt(3, id);
			  ResultSet rs2=pst2.executeQuery();
			  if(rs2.next())
			  {
				    System.out.println("d");
				  	dispatcher1=request.getRequestDispatcher("payslip_admin.jsp");
					request.setAttribute("myname","For this user you have already updated the payslip");
					dispatcher1.forward(request, response);
					con.close();
			  } 
			PreparedStatement pst=con.prepareStatement("insert into pay_slip8( OT_hours ,OT_hours_rate,month_i,year_p,userid) values(?,?,?,?,?)");
			System.out.println(pst);
			String time=ot_hours;            //which is from server;
			String splitTime[]=time.split(":");
			int hours=Integer.parseInt(splitTime[0]);
			int minutes=Integer.parseInt(splitTime[1]);
			int ot_rate=hours*75 + minutes*5;
			//if()
			pst.setString(1, ot_hours);
			pst.setInt(2, ot_rate);
			pst.setString(3, month);
			pst.setInt(4, year_ps);
			pst.setInt(5, id);
			   row_count = pst.executeUpdate();
			   System.out.println(row_count);
			   if(row_count >0)
			   {
				dispatcher=request.getRequestDispatcher("index_user_adminjsp.jsp");
			    
			   }
			else
			{
				dispatcher=request.getRequestDispatcher("payslip_admin.jsp");
			}
			dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println("error");
		}
	}

}
