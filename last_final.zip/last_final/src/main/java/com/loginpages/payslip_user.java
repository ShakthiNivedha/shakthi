package com.loginpages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.xdevapi.Statement;


/**
 * Servlet implementation class payslip_user
 */
@WebServlet("/payslip_user")
public class payslip_user extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	int ae;
	int record;
	int records;
	String ve;
	String da;
	String month;
	String gen;
	int id;
	int basic_pay;
	int desig_id;
	int pf;
	int transport;
	int house;
	int dearness;
	String hours;
	int amount1;
	int amount2;
	int final1;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String mon=request.getParameter("mon");
		String ans=request.getParameter("labelvalue");
		int id_r=Integer.parseInt(request.getParameter("labelvalue1"));
		int year_ps=Integer.parseInt(request.getParameter("year"));
		String year_ps1=request.getParameter("year");
		
		RequestDispatcher  dispatcher=null;
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?allowPublicKeyRetrieval=true&useSSL=false","root","admin@123");
		PreparedStatement pst=con.prepareStatement("select OT_hours,OT_hours_rate,month_i from pay_slip8 where month_i=? and year_p=? and userid=?");
		pst.setString(1, mon);
		pst.setInt(2, year_ps);
		pst.setInt(3, id_r);
		PreparedStatement pst1=con.prepareStatement("select full_name,gender,user_id from empdetails2 where full_name=?");
		pst1.setString(1, ans);
		PreparedStatement pst2=con.prepareStatement("select no_of_days_working from days2 where month_name=?");
		pst2.setString(1,mon);
		PreparedStatement pst3=con.prepareStatement("select designation_id,basic_pay from  designation_entry1 where userid=?");
		pst3.setInt(1,id_r);
		
		//String sql=""; 
		PreparedStatement pst5=con.prepareStatement("select sum(no_of_days) from leave_details5 where userid=? and curr_month=? and nature_of_leave=?");
		pst5.setInt(1, id_r);
		String nature="LAP"; 
		pst5.setString(2,mon); 
		pst5.setString(3,nature); 
		System.out.println(mon);
		//pst5.setString(3,mon);
		ResultSet r=pst5.executeQuery(); 	
		while (r.next())
		{
		       records = r.getInt(1);
		      System.out.println("Count of LAP "+records); 
		    }
		
		String sql1="select sum(no_of_days) from leave_details5 where userid=? and nature_of_leave=? and curr_month=?";//and current_month
		PreparedStatement pst6=con.prepareStatement(sql1);
		pst6.setInt(1, id_r);
		String nature1="CL";
		pst6.setString(2,nature1);
		pst6.setString(3, mon);
		ResultSet r1=pst6.executeQuery();
		while (r1.next()) {
		       record = r1.getInt(1);
		      System.out.println("Count of CL"+record);
		    }
		if(records >=3) {
			int lap_calculation=2-records;   
			int e=Math.abs(lap_calculation);
			amount1=e*500;
			System.out.println(amount1);
			
		}
		if(record >=4) {
			int cl_calculation=3-record;
			int ee=Math.abs(cl_calculation);
			amount2=ee*500;
		} 
		final1=amount1+amount2;
		
		
		ResultSet rs1=pst.executeQuery();
		ResultSet rs2=pst1.executeQuery();
		ResultSet rs3=pst2.executeQuery();
		ResultSet rs4=pst3.executeQuery();
	
			if(rs1.next())
			{
				hours=rs1.getString(1);
			    ae=rs1.getInt(2);
			    month=rs1.getString(3);
			   
			}
			else
			{
		        dispatcher=request.getRequestDispatcher("payslip_user.jsp");
				request.setAttribute("myname","Pay Slip has to be updated by Admin Please Wait");
				dispatcher.forward(request, response);
			}
			
			if(rs2.next())
			{
				ve=rs2.getString(1);
				gen=rs2.getString(2);
				id=rs2.getInt(3);
				
			}
			if(rs3.next())
			{
				da=rs3.getString(1);
			}
			if(rs4.next())
			{
				desig_id=rs4.getInt(1);
				basic_pay=rs4.getInt(2);
			} 
			PreparedStatement pst4=con.prepareStatement("select pf,transport_allowance,house_rent,dearness_allowance from details_storing2 where desig_id=?");
			pst4.setInt(1,desig_id);
			
			ResultSet rs5=pst4.executeQuery();	
			if(rs5.next())
			{
				pf=rs5.getInt(1);
				transport=rs5.getInt(2);
				house=rs5.getInt(3);
				dearness=rs5.getInt(4);
			}
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE html> ");
			out.println("<html>");
			out.println("<head>");
			out.println("<link rel=stylesheet href=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css>");
			out.println("<style>");
			out.println("table{");
			out.println("border:1px solid black;");
			out.println("}");	
			out.println("th, td { ");
			out.println("border:1px solid black; ");
			out.println("border-collapse:collapse; ");
			out.println("width:160px;");
			out.println("height:25px;");
			out.println("text-align:center;");
			out.println("}");
		    out.println(" button{ ");
		    out.println("font-size:24px;");
		    out.println("border:none;");
		    out.println("background-color:white; ");
		    out.println("color:black; ");
			out.println("cursor:pointer;");
			out.println("margin:4px 5px; "); 
			out.println("padding:10px 22px; ");
			out.println("}");
			out.println("body{ ");
			out.println("background-image:url(images_login/all.jpeg); ");
			out.println("background-size:cover; ");
			out.println("background-position:center;");
			out.println("background-repeat:no-repeat; ");
			out.println("background-position:center center;");
			out.println("}");
			out.println("#sha"); 
			out.println("{");
			out.println("width:50%; ");
			out.println("background-color:white;");
			out.println("}"); 
			out.println("#sha1");  
			out.println("{"); 
			out.println("color:white;");  
			out.println("font-size:45px;");  
			out.println("}"); 
			out.println(".sha2{"); 
			out.println("text-align:left;"); 
			out.println("}");
			out.println(".sha3{");
			out.println("width:10%;");
			out.println("}");
			out.println("a{color:white;");
			out.println("text-decoration:none;}");
			
			
			out.println("</style>");
			out.println("</head>  ");
			out.println("<body >");
			
			 out.println("<a  href=index_user.jsp >HOME</a>");
			
			out.println("<center>");
			//out.println("<table id=sha> ");
			out.println("<table id=sha> ");
			//
			out.println("<caption><b><p id=sha1>Employee Payslip</p></b></caption> ");
			out.println("<thead> ");
			out.println("<tr>");
			//<th colspan=1><img src="https://law-all.com/image/cache/catalog/data/Category/Stationery/2021/PPS15-800x800.JPG"  style="width:90px;height:90px;"></th>
			out.println("<th colspan=1><img src=https://law-all.com/image/cache/catalog/data/Category/Stationery/2021/PPS15-800x800.JPG style=width:90px; height:90px; ></img> </th>");
			out.println("<th colspan=4> Integral Coach Factory, Chennai-38<br> A Production unit under Ministry of Railways <br> </th> ");
			out.println("</tr> ");
			out.println("<tr> ");
			out.println("<th colspan=5>Payslip For the Month of "+month+"</th> ");
			out.println("</tr>");
			out.println("<tr> ");
			//
			out.println("<td class=sha2 colspan=3 > ");
			out.println("Employee Name : "+ve+"<br>");
			out.println("Gender : "+gen+"<br>");
			out.println("</td>");
			//
			out.println("<td class=sha2 colspan=2  > ");
			out.println("Paid Days: "+da+"<br>");	
			out.println("</td> ");
			out.println("</tr>"); 
			out.println("</thead>");
			out.println("<tbody> ");
			out.println("<tr > ");
			//
			out.println("<th class=sha3 >Earnings</th>");
			out.println("<th colspan=2 class=sha3>Amount</th>"); 
			out.println("<th class=sha3>Deductions</th>");
			out.println("<th class=sha3 >Amount</th> ");
			out.println("</tr>");
			out.println("<tr> ");
			out.println("<td>Basic Pay</td>");
			out.println("<td colspan=2>"+basic_pay+"</td>");
			out.println("<td>PF Amount</td>");
			out.println("<td>"+pf+"</td>");
			out.println("</tr>");
			out.println("<tr> ");
			out.println("<td>OT Hours</td> ");
			out.println("<td>"+hours+"</td>");
			out.println("<td rowspan=2></td>");
			/*if(records >=31 && record >= 9)
			{
		         int  lap_calculation = 30 - records;  
		         int cl_calculation = 8 - record;
			} */
			
			out.println("<td>Leave Deductions</td>");
			out.println("<td>"+final1+"</td>");
			out.println("</tr>");
			out.println("<tr> ");
			out.println("<td>OT Rate</td> ");
			out.println("<td>75</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td colspan=2>OT Payment</td> ");
			out.println("<td>"+ae+"</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td colspan=2>Transport Allowance</td>");
			int ta=basic_pay*transport/100;
			System.out.println(ta);
			out.println("<td>"+ta+"</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td colspan=2>House Rent Allowance</td>");
			int ha=basic_pay*house/100;
			out.println("<td>"+ha+"</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td colspan=2>Dearness Allowance</td>");
			int dea=basic_pay*dearness/100;
			out.println("<td>"+dea+"</td>");
			out.println("</tr>");
			out.println("</tbody>");
			out.println("<tfoot> ");
			out.println("<tr>"); 
			out.println("<th>Total Payment</th>");
			int finalpay=basic_pay+ha+dea+ta+ae;
			out.println("<td colspan=2>"+finalpay+"</td> ");
			out.println("<td> Total Deduction</td>");
			int deduction=pf+final1;
			out.println("<td>"+deduction+"</td>");
			out.println("</tr>");
			out.println("<tr> ");
			out.println("<th colspan=2><strong>Net Pay:</strong></th>");
			int netpay=finalpay-pf-final1;
			out.println("<td colspan=3> "+netpay+"</td> ");
			out.println("</tr>");
			out.println("</tfoot>");
			out.println("</table>");
			out.println("<br>");
			out.println("<center><button id=btn onclick=hideButton(),window.print() >Print the Slip </button></center>");
			out.println("<script type=text/javascript>");
			out.println("function hideButton(){");
		    
		    out.println("document.getElementById('btn').style.visibility= 'hidden';}"); 
		    
		    out.println("</script>"); 
		    
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");


		}
		catch(Exception e)
		{
			//System.out.println(e);
			e.printStackTrace();
		}
	}

}
