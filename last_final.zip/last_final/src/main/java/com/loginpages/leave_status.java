package com.loginpages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class leave_status
 */
@WebServlet("/leave_status")
public class leave_status extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int emp_id=Integer.parseInt( request.getSession(false).getAttribute("id").toString());
		RequestDispatcher dispatcher=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nearfinal6?useSSL=false","root","admin@123");
			PreparedStatement pst1=con.prepareStatement("select * from leave_details5 where userid=?");
		    pst1.setInt(1,emp_id);
		    System.out.println(emp_id);
			ResultSet rs1=pst1.executeQuery();
			int rowCount = rs1.getRow();
			
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Leave Status</title>");
			out.println("<style>");
			
			out.println("*{");
			out.println("margin:0;");
			out.println("padding: 0;");
			out.println("outline: 0;");
			out.println("}");
			out.println("body{");
			out.println("background-image: url(images_login/all.jpeg);");
			out.println("background-size:100%;");
			out.println("background-size:cover;"); 
			out.println("background-position:center;");
			out.println("background-repeat:no-repeat;");
			out.println("}");
			out.println("table{");
			out.println("position: absolute;");
			out.println("z-index: 2;");
			out.println("left: 50%;");
			out.println("top: 50%;");
			out.println("transform: translate(-50%,-50%);");
			out.println("width: 60%;"); 
			out.println("border-collapse: collapse;");
			out.println("border-spacing: 0;");
			out.println("box-shadow: 0 2px 15px rgba(64,64,64,.7);");
			out.println("border-radius: 12px 12px 0 0;");
			out.println("overflow: hidden;");
			out.println("}");
			out.println("td , th{");
			out.println("padding: 15px 20px;");
			out.println("text-align: center;");
			out.println("}");
			out.println("th{");
			out.println("background-color: #0a010c;");
			out.println("color: #fafafa;");
			out.println("font-family: 'Open Sans',Sans-serif;");
			out.println("font-weight: 200;");
			out.println("text-transform: uppercase;");
			out.println("}");
			out.println("tr{");
			out.println("width: 100%;");
			out.println("background-color: #fafafa;");
			out.println("font-family: 'Montserrat', sans-serif;");
			out.println("}");
			out.println("tr:nth-child(even){");
			out.println("background-color: #eeeeee;");
			out.println("}");
			out.println("button");
			out.println("{");
			out.println("margin-top:570px;");
			out.println("margin-left:690px");
			out.println("background-color: rgb(255, 255, 255);");
			out.println("border: none;");
			out.println("color: black;");
			out.println("padding: 10px 32px;");
			out.println("text-align: center;");
			out.println("text-decoration: none;");
			out.println("font-size: 16px;");
			out.println("cursor: pointer;");
			out.println("border-color: black;");
			out.println("border-radius:20px;");
			out.println("margin-left:690px");
			out.println("}");
			
			out.println("</style>");
			out.println("</head>");
			out.println("<body>");
			 
			out.println("<form method=post action=logic_for_leave_approval>");
			out.println("<div class=filter>");
			out.println("</div>");
			out.println("<table >");
			out.println("<tr>");
			out.println("<th>Leave ID</th>");
			out.println("<th>No of Days</th>");
			out.println("<th>Nature of Leave</th>");
			out.println("<th>Leave Status </th>");
			out.println("<th> From Date </th>");
			out.println("<th>To Date</th>");
			out.println("</tr>");
			while(rs1.next()) {	
				
				int leave_id=rs1.getInt("leave_id");
				int no_of_days=rs1.getInt("no_of_days");
				String reason=rs1.getString("reason");
				String leave_status=rs1.getString("leave_status");
				String from_date=rs1.getString("from_date");
				String to_date=rs1.getString("to_date");
				
				
				
			out.println("<tr>");
			out.println("<td>"+leave_id+"</td>");
			out.println("<td>"+no_of_days+"</td>");
			out.println("<td>"+reason+"</td>");
			out.println("<td>"+leave_status+"</td>");
			out.println("<td>"+from_date+"</td>");
			out.println("<td>"+to_date+"</td>");
			out.println("</tr>");
			
			
			
				
				}
			out.println("</table>");
		
			out.println("</form>");
			
			out.println("</body>");
			out.println("</html>");
		}
		
		catch(Exception ee)
		{
			System.out.println(ee);
		}
	}

}
